from kivy.uix.gridlayout import GridLayout
from kivy.properties import ListProperty, ObjectProperty
from kivy.animation import Animation
from kivy.clock import Clock
from kivy.core.window import Window
from random import randint, random 
from dock import Dock
from kivy.uix.label import Label
from kivy.core.audio import SoundLoader

class Fleet(GridLayout):
    survivors=ListProperty(())
    invasion=ObjectProperty(None)
    shooter=ObjectProperty(None)
    explode_sound=SoundLoader.load('explode.wav')   
    triumph=SoundLoader.load('triumph.wav')
    
    def __init__(self, **kwargs):
        
        super().__init__(**kwargs)
#        self.begin()
        

        self.label=Label(text='32' , markup=True, size_hint=(None, None), size=(200, 20))
        for x in range(0, 32):
            dock=Dock()
            self.add_widget(dock)
            self.survivors.append(dock)
        self.center_x=Window.width/4

    def on_kv_post(self, base_widget):
                
        self.invasion.add_widget(self.label)        
        self.label_x=Window.width-200
        self.label_y=Window.height-50     
        self.label.pos=self.label_x, self.label_y
#        self.start_attack()        

    def start_attack(self, instance, value):
        
        self.invasion.remove_widget(value)
        self.go_left(instance, value)
        self.schedule_events()
        
    def go_left(self, instance, value):
        self.animation=Animation(x=0)
        self.animation.bind(on_complete=self.go_right)
        self.animation.start(self)
        
    def go_right(self, instance, value):
        self.animation=Animation(right=self.parent.width)
        self.animation.bind(on_complete=self.go_left)
        self.animation.start(self)
        
    def schedule_events(self):
        Clock.schedule_interval(self.solo_attack, 2)
        Clock.schedule_once(self.shoot, random())
         
    def solo_attack(self, dt):
        if self.survivors:
            rint=randint(0, len(self.survivors)-1)
            child=self.survivors[rint]
            child.invader.solo_attack()
            
    def shoot(self, dt):
        if self.survivors:
            rint=randint(0, len(self.survivors)-1)
            child=self.survivors[rint]
            child.invader.drop_missile()          
        Clock.schedule_once(self.shoot, random())    
        
    def collide_ammo(self, ammo):
        for child in self.survivors:
            if child.invader.collide_widget(ammo):
                self.explode_sound.play()
                Animation.cancel_all(child.invader)
                child.remove_widget(child.invader)
                self.survivors.remove(child)
                return True
        return False
                
    def on_survivors(self, instance, value):
        self.survivors_num=str(len(self.survivors))+" INVADERS LEFT"
        self.label.text=self.survivors_num         
        if len(self.survivors)==0:
            self.triumph.play()   
            Clock.unschedule(self.solo_attack)    
            Clock.unschedule(self.shoot)
            self.invasion.end_game("You win!")      

           

                  