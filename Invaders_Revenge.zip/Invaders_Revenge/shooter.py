from kivy.clock import Clock
from kivy.uix.image import Image
from kivy.core.audio import SoundLoader
from kivy.animation import Animation
from ammo import Shot

class Shooter(Image):
    
    reloaded=True
    alive=False
    explode_sound=SoundLoader.load('explode.wav')   
    game_over=SoundLoader.load('game_over.wav')
    def on_touch_down(self, touch):
        if self.parent.collide_point(*touch.pos):
            Animation.cancel_all(self)
            self.animation=Animation(center_x=touch.x, d=.5)
            self.animation.start(self)
            touch.ud['move']=True
        elif self.enemy_area.collide_point(*touch.pos):
            self.shoot(touch.x, touch.y)
            touch.ud['shoot']=True
            
    def on_touch_move(self, touch):
        if self.parent.collide_point(*touch.pos):
            Animation.cancel_all(self)
            self.animation=Animation(center_x=touch.x, d=.5)
            self.animation.start(self)
        elif self.enemy_area.collide_point(*touch.pos):
            self.shoot(touch.x, touch.y)
            
    def on_touch_up(self, touch):
        if 'shoot' in touch.ud and touch.ud['shoot']:
            Clock.schedule_once(self.reload_gun, 2)
            
    def start(self, instance, value):
        self.alive=True
        
    def shoot(self, fx, fy):
        if self.reloaded and self.alive:
            self.reloaded=False
            shot=Shot()
            shot.center=(self.center_x, self.top)             
            self.invasion.add_widget(shot)
            (fx, fy)=self.project(self.center_x, self.top, fx, fy)
            shot.shoot(fx, fy, self.invasion.fleet)
            
    def reload_gun(self, dt):
        self.reloaded=True
    
    def collide_ammo(self, ammo):

        if self.collide_widget(ammo) and self.alive:
            self.explode_sound.play()
#            if self.invasion.life:

#                self.invasion.life-=1
#            else:    
            self.alive=False
            self.color=(0,0,0,0)
            self.game_over.play()
            self.invasion.end_game('Game Over.')

            return True
        return False    
        
    def project(self, ix, iy, fx, fy):
        (w, h)= self.invasion.size
        if ix==fx: return (ix, h)
        m=(fy-iy)/(fx-ix)    
        b=iy-m*ix
        x=(h-b)/m
        if x<0: return (0, b)
        elif x>w: return(w, m*w+b)
        return (x, h)
        