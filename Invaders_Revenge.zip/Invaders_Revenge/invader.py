from kivy.core.window import Window
from kivy.uix.image import Image
from kivy.animation import Animation
from random import choice, randint
from ammo import Missile

class Invader(Image):
    prefix=['in_', 'out_', 'in_out_']
    functions=['back','bounce', 'circ', 'cubic', 'elastic', 'expo', 'quad', 'quart', 'quint', 'sine']
    formation=True
    
    def solo_attack(self):
        if self.formation:
            self.parent.unbind_invader()
            #who is self.parent? ==Dock, a  Widget,
            #dock is a widget representing the psace for one invader 
            #in the fleet
            #self.parent=dock
            #self.parent.parent=fleet(this contains a dock for each invader)
            #fleet.parent=enemy area
            #Window=the whole screen
            
        animation=self.trajectory()
        animation.bind(on_complete=self.to_dock)
        animation.start(self)
           
            
    def trajectory(self):
        fleet=self.parent.parent
        area=fleet.parent
        x=choice((-self.width, area.width+self.width))
        low=round(area.y)
        high=round(fleet.y)
        y=randint(min(low, high), max(low, high))
        t=choice(self.prefix)+choice(self.functions)
        return Animation(x=x, y=y, d=randint(2, 7), t=t)
        
    def to_dock(self, instance, value):
        self.y=Window.height
        self.x=Window.width/2
        animation=Animation(pos=self.parent.pos, d=2)
        animation.bind(on_complete=self.parent.bind_invader)
        animation.start(self)
        
    def drop_missile(self):
        fleet=self.parent.parent
        missile=Missile()
        (mx, my)=self.to_window(self.center_x, self.y)
        missile.center=fleet.invasion.to_widget(mx, my)
        fleet.invasion.add_widget(missile)
        missile.shoot(self.center_x, 0, fleet.shooter)
    