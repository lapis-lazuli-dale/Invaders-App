from kivy.uix.image import Image
from kivy.core.audio import SoundLoader

class Boom(Image):
    sound=SoundLoader.load('boom.wav')
    def boom(self):
        if self.sound:
            self.sound.play()
 